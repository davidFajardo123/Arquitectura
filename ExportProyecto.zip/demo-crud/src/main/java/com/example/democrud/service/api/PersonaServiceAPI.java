package com.example.democrud.service.api;

import com.example.democrud.commons.GenericServiceAPI;
import com.example.democrud.model.Persona;

//Se extendiende de GenericServiceAPI
public interface PersonaServiceAPI extends GenericServiceAPI<Persona, Long>  {
	
}
